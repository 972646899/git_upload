
const target=new Date('2026-12-31');
function tick(){
 const d=Math.max(0,Math.floor((target-new Date())/(1000*60*60*24)));
 const e=document.getElementById('countdown');
 if(e)e.innerText=d+' Days';
}
tick();setInterval(tick,60000);
