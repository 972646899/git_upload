
document.querySelectorAll('.card').forEach(c=>{
 c.addEventListener('mouseenter',()=>c.style.transform='translateY(-4px)');
 c.addEventListener('mouseleave',()=>c.style.transform='translateY(0)');
});
